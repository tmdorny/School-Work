PA2 - A  Tim Dorny  u0829896

Compile with: gcc -o a2 prog2.c
and run with: ./a2
