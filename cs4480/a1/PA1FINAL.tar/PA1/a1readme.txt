CS 4480 PA 1 - B Readme

Tim Dorny u0829896

Compile and run program with "python a1.py".
