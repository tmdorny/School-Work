extern int a[];
int e(int i);

int f(int i) {
  return e(a[i]);
}
