First run pa2sever.py with 'python pa2server.py'
While that is running, run pa2client.py with 'python pa2client.py' to initiate the key exchange.
Note that the program used TCP Port 2114.

PA2 for Tim Dorny u0829896
