ran out of time code still buggy
compile with gcc pa1-x -o pa1-x.c
